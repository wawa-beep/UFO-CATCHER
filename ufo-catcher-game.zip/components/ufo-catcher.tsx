"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { Button } from "@/components/ui/button"

interface Prize {
  id: number
  x: number
  y: number
  color: string
  type: "bear" | "star" | "heart" | "ball"
  caught: boolean
}

interface ClawState {
  x: number
  y: number
  isOpen: boolean
  isDescending: boolean
  isAscending: boolean
  isReturning: boolean
  grabbedPrize: Prize | null
}

const GAME_WIDTH = 400
const GAME_HEIGHT = 500
const CLAW_START_Y = 60
const PRIZE_FLOOR_Y = 380
const DROP_ZONE_X = 50

// Claw upgrade levels based on score
function getClawLevel(score: number): number {
  if (score >= 10000) return 5 // Legendary (MAX)
  if (score >= 5000) return 4 // Diamond
  if (score >= 3000) return 3 // Gold
  if (score >= 2000) return 2 // Silver
  if (score >= 1000) return 1 // Bronze
  return 0 // Normal
}

// Get the maximum unlocked level based on high score
function getMaxUnlockedLevel(highScore: number): number {
  return getClawLevel(highScore)
}

// Level requirements for display
const LEVEL_REQUIREMENTS = [
  { level: 0, score: 0, name: "Normal" },
  { level: 1, score: 1000, name: "Bronze" },
  { level: 2, score: 2000, name: "Silver" },
  { level: 3, score: 3000, name: "Gold" },
  { level: 4, score: 5000, name: "Diamond" },
  { level: 5, score: 10000, name: "Legendary" },
]

function getClawStyle(level: number) {
  const styles = [
    { // Level 0 - Normal
      armColor: "hsl(var(--muted))",
      strokeColor: "hsl(var(--muted-foreground))",
      mountColor: "hsl(var(--muted))",
      glow: "none",
      particles: false,
      name: "Normal",
      emoji: "",
    },
    { // Level 1 - Bronze
      armColor: "#CD7F32",
      strokeColor: "#8B4513",
      mountColor: "#B87333",
      glow: "drop-shadow(0 0 4px #CD7F32)",
      particles: false,
      name: "Bronze",
      emoji: "",
    },
    { // Level 2 - Silver
      armColor: "#C0C0C0",
      strokeColor: "#808080",
      mountColor: "#A8A8A8",
      glow: "drop-shadow(0 0 6px #C0C0C0)",
      particles: false,
      name: "Silver",
      emoji: "",
    },
    { // Level 3 - Gold
      armColor: "#FFD700",
      strokeColor: "#DAA520",
      mountColor: "#FFC125",
      glow: "drop-shadow(0 0 8px #FFD700)",
      particles: true,
      name: "Gold",
      emoji: "",
    },
    { // Level 4 - Diamond
      armColor: "#B9F2FF",
      strokeColor: "#00CED1",
      mountColor: "#E0FFFF",
      glow: "drop-shadow(0 0 10px #00FFFF) drop-shadow(0 0 20px #00CED1)",
      particles: true,
      name: "Diamond",
      emoji: "",
    },
    { // Level 5 - Legendary
      armColor: "url(#legendaryGradient)",
      strokeColor: "#FF1493",
      mountColor: "#FF69B4",
      glow: "drop-shadow(0 0 12px #FF1493) drop-shadow(0 0 24px #FFD700)",
      particles: true,
      name: "Legendary",
      emoji: "",
    },
  ]
  return styles[level] || styles[0]
}

export function UFOCatcher() {
  const [claw, setClaw] = useState<ClawState>({
    x: GAME_WIDTH / 2,
    y: CLAW_START_Y,
    isOpen: true,
    isDescending: false,
    isAscending: false,
    isReturning: false,
    grabbedPrize: null,
  })

  const [prizes, setPrizes] = useState<Prize[]>([])
  const [score, setScore] = useState(0)
  const [highScore, setHighScore] = useState(0)
  const [credits, setCredits] = useState(3)
  const [gameState, setGameState] = useState<"idle" | "moving" | "dropping" | "grabbing" | "returning">("idle")
  const [screenState, setScreenState] = useState<"menu" | "armSelect" | "playing">("menu")
  const [selectedArmLevel, setSelectedArmLevel] = useState(0)
  const [isMovingLeft, setIsMovingLeft] = useState(false)
  const [isMovingRight, setIsMovingRight] = useState(false)
  const animationRef = useRef<number>()

  // Load high score from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem("ufo-catcher-highscore")
    if (saved) {
      setHighScore(Number.parseInt(saved, 10))
    }
  }, [])

  // Save high score when score changes
  useEffect(() => {
    if (score > highScore) {
      setHighScore(score)
      localStorage.setItem("ufo-catcher-highscore", score.toString())
    }
  }, [score, highScore])

  // Initialize prizes
  useEffect(() => {
    const initialPrizes: Prize[] = [
      { id: 1, x: 80, y: PRIZE_FLOOR_Y, color: "#FF6B9D", type: "bear", caught: false },
      { id: 2, x: 140, y: PRIZE_FLOOR_Y + 10, color: "#45B7D1", type: "star", caught: false },
      { id: 3, x: 200, y: PRIZE_FLOOR_Y - 5, color: "#96CEB4", type: "heart", caught: false },
      { id: 4, x: 260, y: PRIZE_FLOOR_Y + 5, color: "#FFEAA7", type: "ball", caught: false },
      { id: 5, x: 320, y: PRIZE_FLOOR_Y, color: "#DDA0DD", type: "bear", caught: false },
      { id: 6, x: 110, y: PRIZE_FLOOR_Y + 15, color: "#FF7F50", type: "star", caught: false },
      { id: 7, x: 230, y: PRIZE_FLOOR_Y + 8, color: "#98D8C8", type: "heart", caught: false },
      { id: 8, x: 290, y: PRIZE_FLOOR_Y - 3, color: "#F7DC6F", type: "ball", caught: false },
    ]
    setPrizes(initialPrizes)
  }, [])

  // Movement logic
  useEffect(() => {
    if (gameState !== "idle" && gameState !== "moving") return

    const moveSpeed = 1.5
    let frameId: number

    const move = () => {
      setClaw((prev) => {
        let newX = prev.x
        if (isMovingLeft) newX = Math.max(60, prev.x - moveSpeed)
        if (isMovingRight) newX = Math.min(GAME_WIDTH - 60, prev.x + moveSpeed)
        return { ...prev, x: newX }
      })
      if (isMovingLeft || isMovingRight) {
        frameId = requestAnimationFrame(move)
      }
    }

    if (isMovingLeft || isMovingRight) {
      if (gameState === "idle") setGameState("moving")
      frameId = requestAnimationFrame(move)
    } else if (gameState === "moving") {
      setGameState("idle")
    }

    return () => {
      if (frameId) cancelAnimationFrame(frameId)
    }
  }, [isMovingLeft, isMovingRight, gameState])

// Drop and grab animation
  const dropClaw = useCallback(() => {
    if (gameState !== "idle" && gameState !== "moving") return
  
    setGameState("dropping")
    setIsMovingLeft(false)
    setIsMovingRight(false)

    const dropAnimation = () => {
      let hasGrabbed = false
      let grabbedPrize: Prize | null = null

      setClaw((prev) => {
        if (prev.y < PRIZE_FLOOR_Y - 20) {
          return { ...prev, y: prev.y + 4, isOpen: true }
        }

        // Check for prize collision
        const nearbyPrize = prizes.find(
          (p) => !p.caught && Math.abs(p.x - prev.x) < 35 && Math.abs(p.y - prev.y) < 50
        )

        if (nearbyPrize && Math.random() > 0.3) {
          hasGrabbed = true
          grabbedPrize = nearbyPrize
          return { ...prev, isOpen: false, grabbedPrize: nearbyPrize }
        }

        return { ...prev, isOpen: false }
      })

      if (hasGrabbed && grabbedPrize) {
        setPrizes((prev) =>
          prev.map((p) => (p.id === grabbedPrize!.id ? { ...p, caught: true } : p))
        )
      }

      setClaw((prev) => {
        if (prev.y >= PRIZE_FLOOR_Y - 20) {
          setGameState("grabbing")
          return prev
        }
        return prev
      })
    }

    const animateDown = () => {
      setClaw((prev) => {
        if (prev.y < PRIZE_FLOOR_Y - 20) {
          animationRef.current = requestAnimationFrame(animateDown)
          return { ...prev, y: prev.y + 4 }
        }
        return prev
      })
    }

    // Animate down
    const goDown = () => {
      setClaw((prev) => {
        if (prev.y < PRIZE_FLOOR_Y - 20) {
          requestAnimationFrame(goDown)
          return { ...prev, y: prev.y + 2 }
        } else {
          // Try to grab
          setTimeout(() => grabAndReturn(), 300)
          return { ...prev, isOpen: false }
        }
      })
    }

    goDown()
  }, [credits, gameState, prizes])

  const grabAndReturn = useCallback(() => {
    setClaw((prev) => {
      // Check for prize
      const nearbyPrize = prizes.find(
        (p) => !p.caught && Math.abs(p.x - prev.x) < 35
      )
      
      const willGrab = nearbyPrize && Math.random() > 0.35
      
      if (willGrab && nearbyPrize) {
        setPrizes((ps) => ps.map((p) => (p.id === nearbyPrize.id ? { ...p, caught: true } : p)))
        return { ...prev, isOpen: false, grabbedPrize: nearbyPrize }
      }
      
      return { ...prev, isOpen: false, grabbedPrize: null }
    })

    setGameState("returning")
    
    // Animate up first
    const goUp = () => {
      setClaw((prev) => {
        if (prev.y > CLAW_START_Y) {
          requestAnimationFrame(goUp)
          return { ...prev, y: prev.y - 1.5 }
        } else {
          // Move to drop zone
          setTimeout(() => moveToDropZone(), 100)
          return prev
        }
      })
    }

    setTimeout(goUp, 200)
  }, [prizes])

  const moveToDropZone = useCallback(() => {
    const goLeft = () => {
      setClaw((prev) => {
        if (prev.x > DROP_ZONE_X) {
          requestAnimationFrame(goLeft)
          return { ...prev, x: prev.x - 1.5 }
        } else {
          // Drop prize
          setTimeout(() => dropPrize(), 100)
          return prev
        }
      })
    }
    goLeft()
  }, [])

  const dropPrize = useCallback(() => {
    setClaw((prev) => {
      if (prev.grabbedPrize) {
        setScore((s) => s + 100)
      }
      return { ...prev, isOpen: true, grabbedPrize: null }
    })

    // Return to center
    setTimeout(() => returnToCenter(), 500)
  }, [])

  const returnToCenter = useCallback(() => {
    const goCenter = () => {
      setClaw((prev) => {
        const targetX = GAME_WIDTH / 2
        if (Math.abs(prev.x - targetX) > 1.5) {
          requestAnimationFrame(goCenter)
          return { ...prev, x: prev.x + (prev.x < targetX ? 1.5 : -1.5) }
        } else {
          setGameState("idle")
          return { ...prev, x: targetX, isOpen: true }
        }
      })
    }
    goCenter()
  }, [])

  const resetGame = () => {
    setCredits(3)
    setScore(0)
    setPrizes([
      { id: 1, x: 80, y: PRIZE_FLOOR_Y, color: "#FF6B9D", type: "bear", caught: false },
      { id: 2, x: 140, y: PRIZE_FLOOR_Y + 10, color: "#45B7D1", type: "star", caught: false },
      { id: 3, x: 200, y: PRIZE_FLOOR_Y - 5, color: "#96CEB4", type: "heart", caught: false },
      { id: 4, x: 260, y: PRIZE_FLOOR_Y + 5, color: "#FFEAA7", type: "ball", caught: false },
      { id: 5, x: 320, y: PRIZE_FLOOR_Y, color: "#DDA0DD", type: "bear", caught: false },
      { id: 6, x: 110, y: PRIZE_FLOOR_Y + 15, color: "#FF7F50", type: "star", caught: false },
      { id: 7, x: 230, y: PRIZE_FLOOR_Y + 8, color: "#98D8C8", type: "heart", caught: false },
      { id: 8, x: 290, y: PRIZE_FLOOR_Y - 3, color: "#F7DC6F", type: "ball", caught: false },
    ])
    setClaw({
      x: GAME_WIDTH / 2,
      y: CLAW_START_Y,
      isOpen: true,
      isDescending: false,
      isAscending: false,
      isReturning: false,
      grabbedPrize: null,
    })
    setGameState("idle")
  }

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") setIsMovingLeft(true)
      if (e.key === "ArrowRight") setIsMovingRight(true)
      if (e.key === " " || e.key === "Enter") {
        e.preventDefault()
        dropClaw()
      }
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") setIsMovingLeft(false)
      if (e.key === "ArrowRight") setIsMovingRight(false)
    }

    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("keyup", handleKeyUp)

    return () => {
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("keyup", handleKeyUp)
    }
  }, [dropClaw])

  // Menu Screen Component
  const MenuScreen = () => (
    <div 
      className="flex flex-col items-center justify-center gap-8 p-8 rounded-2xl border-4 border-primary/50"
      style={{ 
        width: GAME_WIDTH, 
        height: GAME_HEIGHT,
        background: 'linear-gradient(180deg, hsl(220 20% 8%) 0%, hsl(220 25% 12%) 100%)'
      }}
    >
      <h1 className="text-3xl font-bold text-primary tracking-wider" style={{ fontFamily: 'var(--font-pixel)' }}>
        UFO CATCHER
      </h1>
      
      <div className="flex flex-col items-center gap-2">
        <span className="text-muted-foreground text-xs">HIGH SCORE</span>
        <span className="text-2xl text-accent font-bold">{highScore}</span>
      </div>

      <div className="flex flex-col gap-4 w-48">
        <Button
          onClick={() => setScreenState("playing")}
          className="w-full bg-primary text-primary-foreground hover:bg-primary/80 text-sm py-6"
          style={{ fontFamily: 'var(--font-pixel)' }}
        >
          START GAME
        </Button>
        
        <Button
          onClick={() => setScreenState("armSelect")}
          variant="outline"
          className="w-full border-2 border-secondary text-secondary hover:bg-secondary/20 text-sm py-6 bg-transparent"
          style={{ fontFamily: 'var(--font-pixel)' }}
        >
          SELECT ARM
        </Button>
      </div>

      <div className="text-center text-muted-foreground text-xs mt-4">
        <p>Unlock arms by scoring high!</p>
        <p className="mt-1">Next unlock: {
          LEVEL_REQUIREMENTS.find(l => l.score > highScore)?.score.toLocaleString() || "MAX"
        } pts</p>
      </div>
    </div>
  )

  // Arm Selection Screen Component
  const ArmSelectScreen = () => {
    const maxUnlocked = getMaxUnlockedLevel(highScore)
    
    return (
      <div 
        className="flex flex-col items-center gap-4 p-6 rounded-2xl border-4 border-primary/50 overflow-auto"
        style={{ 
          width: GAME_WIDTH, 
          height: GAME_HEIGHT,
          background: 'linear-gradient(180deg, hsl(220 20% 8%) 0%, hsl(220 25% 12%) 100%)'
        }}
      >
        <h2 className="text-xl font-bold text-primary" style={{ fontFamily: 'var(--font-pixel)' }}>
          SELECT ARM
        </h2>
        
        <div className="grid grid-cols-2 gap-3 w-full px-2">
          {LEVEL_REQUIREMENTS.map((req) => {
            const isUnlocked = req.level <= maxUnlocked
            const isSelected = selectedArmLevel === req.level
            const style = getClawStyle(req.level)
            
            return (
              <button
                key={req.level}
                onClick={() => isUnlocked && setSelectedArmLevel(req.level)}
                disabled={!isUnlocked}
                className={`
                  relative p-3 rounded-xl border-2 transition-all
                  ${isSelected ? 'border-primary bg-primary/20' : 'border-muted'}
                  ${isUnlocked ? 'hover:border-primary/50 cursor-pointer' : 'opacity-50 cursor-not-allowed'}
                `}
              >
                {/* Arm Preview */}
                <div className="flex justify-center mb-2" style={{ filter: style.glow }}>
                  <svg width="40" height="50" viewBox="0 0 40 50">
                    <defs>
                      <linearGradient id={`grad-${req.level}`} x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#FF1493" />
                        <stop offset="50%" stopColor="#FFD700" />
                        <stop offset="100%" stopColor="#00FFFF" />
                      </linearGradient>
                    </defs>
                    {/* Mount */}
                    <rect x="12" y="0" width="16" height="10" rx="2" fill={style.mountColor} />
                    {/* Arms */}
                    <path d="M8 10 L4 45 L10 45 L16 10" fill={req.level === 5 ? `url(#grad-${req.level})` : style.armColor} stroke={style.strokeColor} strokeWidth="1" />
                    <path d="M24 10 L30 45 L36 45 L32 10" fill={req.level === 5 ? `url(#grad-${req.level})` : style.armColor} stroke={style.strokeColor} strokeWidth="1" />
                    {/* Gems for gold+ */}
                    {req.level >= 3 && (
                      <>
                        <circle cx="10" cy="28" r="3" fill={req.level >= 5 ? '#FF1493' : req.level >= 4 ? '#00FFFF' : '#FFFFFF'} />
                        <circle cx="30" cy="28" r="3" fill={req.level >= 5 ? '#FF1493' : req.level >= 4 ? '#00FFFF' : '#FFFFFF'} />
                      </>
                    )}
                    {/* Crown for legendary */}
                    {req.level >= 5 && (
                      <g transform="translate(10, -8)">
                        <path d="M0 12 L2 4 L5 8 L10 0 L15 8 L18 4 L20 12 Z" fill="#FFD700" stroke="#DAA520" strokeWidth="0.5"/>
                      </g>
                    )}
                    {/* Diamond gem */}
                    {req.level === 4 && (
                      <path d="M20 -2 L26 4 L20 12 L14 4 Z" fill="#B9F2FF" stroke="#00CED1" strokeWidth="0.5"/>
                    )}
                  </svg>
                </div>
                
                <div className="text-center">
                  <div 
                    className="text-xs font-bold"
                    style={{ 
                      color: req.level >= 3 ? '#FFD700' : req.level >= 1 ? '#C0C0C0' : 'hsl(var(--foreground))',
                      fontFamily: 'var(--font-pixel)'
                    }}
                  >
                    {style.name}
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-1">
                    {isUnlocked ? (
                      isSelected ? "EQUIPPED" : "UNLOCKED"
                    ) : (
                      `${req.score.toLocaleString()} pts`
                    )}
                  </div>
                </div>

                {/* Lock icon */}
                {!isUnlocked && (
                  <div className="absolute inset-0 flex items-center justify-center bg-background/50 rounded-xl">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-muted-foreground">
                      <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                      <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                    </svg>
                  </div>
                )}

                {/* Selected indicator */}
                {isSelected && isUnlocked && (
                  <div className="absolute top-1 right-1">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="hsl(var(--primary))">
                      <path d="M20 6L9 17l-5-5" stroke="hsl(var(--primary))" strokeWidth="3" fill="none"/>
                    </svg>
                  </div>
                )}
              </button>
            )
          })}
        </div>

        <Button
          onClick={() => setScreenState("menu")}
          variant="outline"
          className="mt-2 border-primary text-primary hover:bg-primary/20 bg-transparent"
          style={{ fontFamily: 'var(--font-pixel)' }}
        >
          BACK TO MENU
        </Button>
      </div>
    )
  }

  // Show menu or arm select screen
  if (screenState === "menu") {
    return (
      <div className="flex flex-col items-center gap-6 p-4">
        <MenuScreen />
      </div>
    )
  }

  if (screenState === "armSelect") {
    return (
      <div className="flex flex-col items-center gap-6 p-4">
        <ArmSelectScreen />
      </div>
    )
  }

  return (
    <div className="flex flex-col items-center gap-6 p-4">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-2xl md:text-3xl font-bold text-primary tracking-wider" style={{ fontFamily: 'var(--font-pixel)' }}>
          UFO CATCHER
        </h1>
        <p className="text-muted-foreground text-sm mt-2">Get the prizes!</p>
      </div>

      {/* Score Display */}
      <div className="flex gap-6 text-lg" style={{ fontFamily: 'var(--font-pixel)' }}>
        <div className="flex items-center gap-2">
          <span className="text-muted-foreground text-xs">SCORE</span>
          <span className="text-accent text-sm">{score}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-muted-foreground text-xs">HIGH</span>
          <span className="text-primary text-sm">{highScore}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-muted-foreground text-xs">ARM</span>
          <span 
            className="text-sm font-bold"
            style={{ 
              color: selectedArmLevel >= 3 ? '#FFD700' : selectedArmLevel >= 1 ? '#C0C0C0' : 'hsl(var(--muted-foreground))',
              textShadow: selectedArmLevel >= 4 ? '0 0 8px currentColor' : 'none'
            }}
          >
            {getClawStyle(selectedArmLevel).name}
          </span>
        </div>
      </div>

      {/* Game Cabinet */}
      <div 
        className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-primary/50"
        style={{ 
          width: GAME_WIDTH, 
          height: GAME_HEIGHT,
          background: 'linear-gradient(180deg, hsl(220 20% 8%) 0%, hsl(220 25% 12%) 100%)'
        }}
      >
        {/* Top rail */}
        <div className="absolute top-8 left-4 right-4 h-2 bg-muted rounded-full" />
        
        {/* Drop Zone */}
        <div 
          className="absolute left-2 top-16 bottom-20 w-14 rounded-lg border-2 border-dashed border-accent/50 flex items-end justify-center"
          style={{ background: 'hsla(160, 60%, 45%, 0.1)' }}
        >
          <span className="text-accent/70 text-[8px] mb-2" style={{ fontFamily: 'var(--font-pixel)' }}>GET!</span>
        </div>

        {/* Claw Assembly */}
        {(() => {
          const clawLevel = selectedArmLevel
          const clawStyle = getClawStyle(clawLevel)
          return (
            <div 
              className="absolute transition-none"
              style={{ 
                left: claw.x - 20, 
                top: claw.y - 20,
                transition: 'none',
                filter: clawStyle.glow
              }}
            >
              {/* Sparkle particles for high level claws */}
              {clawStyle.particles && (
                <div className="absolute -inset-4 pointer-events-none">
                  {[...Array(6)].map((_, i) => (
                    <div
                      key={i}
                      className="absolute w-1 h-1 rounded-full animate-pulse"
                      style={{
                        background: clawLevel >= 5 ? '#FFD700' : clawLevel >= 4 ? '#00FFFF' : '#FFD700',
                        left: `${20 + Math.sin(i * 60 * Math.PI / 180) * 25}px`,
                        top: `${15 + Math.cos(i * 60 * Math.PI / 180) * 15}px`,
                        animationDelay: `${i * 0.15}s`,
                        boxShadow: `0 0 4px ${clawLevel >= 5 ? '#FF1493' : clawLevel >= 4 ? '#00FFFF' : '#FFD700'}`
                      }}
                    />
                  ))}
                </div>
              )}

              {/* Claw mount */}
              <div 
                className="w-10 h-6 rounded-b-lg mx-auto relative"
                style={{ background: clawStyle.mountColor }}
              >
                <div 
                  className="absolute -top-8 left-1/2 -translate-x-1/2 w-1 h-8"
                  style={{ background: clawStyle.strokeColor }}
                />
                {/* Crown for legendary */}
                {clawLevel >= 5 && (
                  <div className="absolute -top-12 left-1/2 -translate-x-1/2 text-lg">
                    <svg width="20" height="16" viewBox="0 0 20 16">
                      <path d="M0 14 L2 6 L5 10 L10 2 L15 10 L18 6 L20 14 Z" fill="#FFD700" stroke="#DAA520" strokeWidth="1"/>
                      <circle cx="3" cy="6" r="2" fill="#FF1493"/>
                      <circle cx="10" cy="2" r="2" fill="#FF1493"/>
                      <circle cx="17" cy="6" r="2" fill="#FF1493"/>
                    </svg>
                  </div>
                )}
                {/* Gem for diamond */}
                {clawLevel === 4 && (
                  <div className="absolute -top-10 left-1/2 -translate-x-1/2">
                    <svg width="12" height="12" viewBox="0 0 12 12">
                      <path d="M6 0 L12 4 L6 12 L0 4 Z" fill="#B9F2FF" stroke="#00CED1" strokeWidth="1"/>
                    </svg>
                  </div>
                )}
              </div>
              
              {/* Claw arms */}
              <svg width="40" height="40" viewBox="0 0 40 40" className="mx-auto">
                <defs>
                  <linearGradient id="legendaryGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#FF1493" />
                    <stop offset="25%" stopColor="#FFD700" />
                    <stop offset="50%" stopColor="#00FFFF" />
                    <stop offset="75%" stopColor="#FF1493" />
                    <stop offset="100%" stopColor="#FFD700" />
                  </linearGradient>
                </defs>
                <g style={{ 
                  transformOrigin: '20px 0px',
                  transition: 'transform 0.2s ease'
                }}>
                  {/* Left arm */}
                  <path 
                    d={claw.isOpen ? "M8 0 L4 35 L10 35 L16 0" : "M12 0 L10 35 L14 35 L16 0"} 
                    fill={clawStyle.armColor}
                    stroke={clawStyle.strokeColor}
                    strokeWidth={clawLevel >= 3 ? 2 : 1}
                  />
                  {/* Right arm */}
                  <path 
                    d={claw.isOpen ? "M24 0 L30 35 L36 35 L32 0" : "M24 0 L26 35 L30 35 L28 0"} 
                    fill={clawStyle.armColor}
                    stroke={clawStyle.strokeColor}
                    strokeWidth={clawLevel >= 3 ? 2 : 1}
                  />
                  {/* Decorative gems for gold+ */}
                  {clawLevel >= 3 && (
                    <>
                      <circle cx="10" cy="18" r="3" fill={clawLevel >= 5 ? '#FF1493' : clawLevel >= 4 ? '#00FFFF' : '#FFFFFF'} />
                      <circle cx="30" cy="18" r="3" fill={clawLevel >= 5 ? '#FF1493' : clawLevel >= 4 ? '#00FFFF' : '#FFFFFF'} />
                    </>
                  )}
                </g>
              </svg>

              {/* Grabbed prize indicator */}
              {claw.grabbedPrize && !claw.isOpen && (
                <div 
                  className="absolute top-10 left-1/2 -translate-x-1/2"
                >
                  <PrizeIcon type={claw.grabbedPrize.type} color={claw.grabbedPrize.color} size={28} />
                </div>
              )}
            </div>
          )
        })()}

        {/* Prizes */}
        {prizes.filter(p => !p.caught).map((prize) => (
          <div
            key={prize.id}
            className="absolute transition-all duration-100"
            style={{ left: prize.x - 15, top: prize.y - 15 }}
          >
            <PrizeIcon type={prize.type} color={prize.color} size={30} />
          </div>
        ))}

        {/* Glass reflection */}
        <div 
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'linear-gradient(135deg, rgba(255,255,255,0.1) 0%, transparent 50%, transparent 100%)'
          }}
        />

        {/* Floor */}
        <div className="absolute bottom-12 left-4 right-4 h-3 bg-muted rounded-full" />

        {/* Prize exit */}
        <div className="absolute bottom-0 left-0 right-0 h-12 bg-muted/50 flex items-center justify-center">
          <div className="text-[10px] text-muted-foreground" style={{ fontFamily: 'var(--font-pixel)' }}>
            PRIZE EXIT
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-col items-center gap-4">
        {/* Direction buttons */}
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="lg"
            className="w-16 h-16 rounded-full border-2 border-primary/50 text-primary hover:bg-primary/20 active:scale-95 transition-transform bg-transparent"
            onMouseDown={() => setIsMovingLeft(true)}
            onMouseUp={() => setIsMovingLeft(false)}
            onMouseLeave={() => setIsMovingLeft(false)}
            onTouchStart={() => setIsMovingLeft(true)}
            onTouchEnd={() => setIsMovingLeft(false)}
            disabled={gameState !== "idle" && gameState !== "moving"}
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <path d="M15 19l-7-7 7-7" stroke="currentColor" strokeWidth="2" fill="none" />
            </svg>
          </Button>

          <Button
            size="lg"
            className="w-20 h-20 rounded-full bg-secondary text-secondary-foreground hover:bg-secondary/80 active:scale-95 transition-transform text-xs font-bold"
            style={{ fontFamily: 'var(--font-pixel)' }}
            onClick={dropClaw}
            disabled={gameState !== "idle" && gameState !== "moving"}
          >
            GO!
          </Button>

          <Button
            variant="outline"
            size="lg"
            className="w-16 h-16 rounded-full border-2 border-primary/50 text-primary hover:bg-primary/20 active:scale-95 transition-transform bg-transparent"
            onMouseDown={() => setIsMovingRight(true)}
            onMouseUp={() => setIsMovingRight(false)}
            onMouseLeave={() => setIsMovingRight(false)}
            onTouchStart={() => setIsMovingRight(true)}
            onTouchEnd={() => setIsMovingRight(false)}
            disabled={gameState !== "idle" && gameState !== "moving"}
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <path d="M9 5l7 7-7 7" stroke="currentColor" strokeWidth="2" fill="none" />
            </svg>
          </Button>
        </div>

        {/* Instructions */}
        <div className="text-center text-muted-foreground text-xs">
          <p>Use arrow keys or buttons to move</p>
          <p>Press SPACE or tap GO! to drop</p>
        </div>

        {/* Back to menu */}
        <Button
          onClick={() => setScreenState("menu")}
          variant="ghost"
          className="text-muted-foreground hover:text-foreground text-xs"
          style={{ fontFamily: 'var(--font-pixel)' }}
        >
          MENU
        </Button>
      </div>
    </div>
  )
}

function PrizeIcon({ type, color, size }: { type: Prize["type"]; color: string; size: number }) {
  switch (type) {
    case "bear":
      return (
        <svg width={size} height={size} viewBox="0 0 32 32">
          <circle cx="6" cy="8" r="5" fill={color} />
          <circle cx="26" cy="8" r="5" fill={color} />
          <circle cx="16" cy="18" r="12" fill={color} />
          <circle cx="12" cy="16" r="2" fill="#333" />
          <circle cx="20" cy="16" r="2" fill="#333" />
          <ellipse cx="16" cy="21" rx="3" ry="2" fill="#333" />
        </svg>
      )
    case "star":
      return (
        <svg width={size} height={size} viewBox="0 0 32 32">
          <path
            d="M16 2 L19 12 L30 12 L21 18 L24 28 L16 22 L8 28 L11 18 L2 12 L13 12 Z"
            fill={color}
            stroke="#fff"
            strokeWidth="1"
          />
        </svg>
      )
    case "heart":
      return (
        <svg width={size} height={size} viewBox="0 0 32 32">
          <path
            d="M16 28 C8 20 2 14 2 9 C2 4 6 2 10 2 C13 2 15 4 16 6 C17 4 19 2 22 2 C26 2 30 4 30 9 C30 14 24 20 16 28"
            fill={color}
          />
        </svg>
      )
    case "ball":
      return (
        <svg width={size} height={size} viewBox="0 0 32 32">
          <circle cx="16" cy="16" r="14" fill={color} />
          <path
            d="M4 16 Q16 8 28 16 Q16 24 4 16"
            fill="none"
            stroke="#fff"
            strokeWidth="2"
          />
          <line x1="16" y1="2" x2="16" y2="30" stroke="#fff" strokeWidth="2" />
        </svg>
      )
  }
}
