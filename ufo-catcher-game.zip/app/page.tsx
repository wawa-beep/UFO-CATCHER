import { UFOCatcher } from "@/components/ufo-catcher"

export default function Page() {
  return (
    <main className="min-h-screen bg-background flex items-center justify-center py-8">
      <UFOCatcher />
    </main>
  )
}
