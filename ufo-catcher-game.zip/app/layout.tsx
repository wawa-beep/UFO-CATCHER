import React from "react"
import type { Metadata } from 'next'
import { Press_Start_2P, Inter } from 'next/font/google'

import './globals.css'

const pressStart = Press_Start_2P({ 
  weight: '400',
  subsets: ['latin'],
  variable: '--font-pixel'
})
const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'UFO Catcher',
  description: 'Play the classic crane game!',
  generator: 'v0.app',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ja">
      <body className={`${pressStart.variable} ${inter.className} antialiased`}>{children}</body>
    </html>
  )
}
